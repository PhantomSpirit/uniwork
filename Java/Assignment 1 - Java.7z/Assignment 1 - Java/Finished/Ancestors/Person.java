package Ancestors;

public class Person
{
    public String firstName;
    public String lastName;
    public Person mother;
    public Person father;
    
    public Person(String name1,String name2)
    {
        firstName = name1;
        lastName = name2;
    }
    
    public String getFirstName()
    {
        return firstName;
    }
    
    public String getLastName()
    {
        return lastName;
    }
    
    public void setMother(Person mum)
    {
        mother = mum;
    }
    
    public String getMother()
    {
        return mother.getFirstName() + " " + mother.getLastName();
    }
    
    public void setFather(Person dad)
    {
        father = dad;
    }
    
    public String getFather()
    {
        return father.getFirstName() + " " + father.getLastName();
    }
    
    public String getName()
    {
        return firstName + " " + lastName;
    }
    
    public static void printAncestors(Person p)
    {
        // the if/else statements checks if person X has parents if it doesn't have a parent it will print
        // null, else it will proceed with calling upon the values set in the Ancestors package and call
        //upon the set names
        if ((p.mother == null) && (p.father == null))
        {
        }
        else
        {
            System.out.println(p.getName() + "'s Parents are:");
            System.out.println(p.getFather());
            System.out.println(p.getMother());
            if (p.father != null)
            {
                printAncestors(p.father);
            }
            if (p.mother != null)
            {
                printAncestors(p.mother);
            }
        }
            
    }
}