package Ancestors;

public class Ancestor
{
    public static void main(String[] args)
    {
        Person a = new Person("John","Smith");
        
        Person b = new Person("Anthony","Smith");
        
        Person c = new Person("Samantha","Smith");
        
        Person d = new Person("James","Smith");
        
        Person e = new Person("Ann","Smith");
        
        Person f = new Person("Louise","Novak");
        
        Person g = new Person("Thomas","Novak");
        // a-f are used here to specify the person and to help with the printing order
        a.setMother(c);
        a.setFather(b);
        b.setMother(e);
        b.setFather(d);
        c.setMother(f);
        c.setFather(g);
        // values a-c, are used in pairs to specify the parents of the given person in sets and for easier calling
        Person.printAncestors(a);
    }
}