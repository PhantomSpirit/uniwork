import java.util.Scanner;
//imported packages
public class Account 
{
    //initializes values as integers
    private int openingBalance;
    private int currentBalance;
    private int creditLimit;
    private String customerName;
    private String customerAddress;
    
    // Static variable to store the total number of accounts
    public static int numOfAccounts = 0;

    /**
     * Constructor
     */
    public Account(int startAmount, int balance, int credit, String addy, String nom)  
    {       
        openingBalance = startAmount;
        currentBalance = balance;
        creditLimit = credit;
        customerName = nom;
        customerAddress = addy;
        numOfAccounts++;
    }

    /**
     * Set the balance
     */
    public void setBalance( int amount)  
    {
        currentBalance = amount;
    }

    /**
     * Get the balance
     */
    public int getBalance()   
    {
        return currentBalance;
    }

    /**
     * Set the credit limit
     */
    public void setCreditLimit(int amount) 
    {
        creditLimit = amount;
    }

    /**
     * Get the credit limit
     */
    public int getCreditLimit()   
    {
        return creditLimit;
    }

    /**
     * Show the current balance and the credit limit
     */ 
    public void showData()     
    {
        System.out.println("Customer name: " + customerName);
        System.out.println("Customer Address: " + customerAddress);
        System.out.println("Balance: " + currentBalance); 
        System.out.println("Credit: " + creditLimit);
    }
    
    public void setAddress()
    {
        System.out.println("Please enter the customer's address: ");
        Scanner address = new Scanner(System.in);
        customerAddress = address.nextLine();
    }
    
    public String getAddress()
    {
        return customerAddress;
    }
    
      public void setName()
    {
        System.out.println("Please enter the customer's name: ");
        Scanner name = new Scanner(System.in);
        customerName = name.nextLine();
    }
    
    public String getName()
    {
        return customerName;
    }
    
    
}
