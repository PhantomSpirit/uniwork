/**
 * Orchestration class for Accounts
 */
import java.util.Scanner;
public class AccountDemo
{
    public static void main(String [] args)  
    {
        Scanner input = new Scanner(System.in);
        //creates a scanner inpput
        //sets account base values and address
        Account accountOne = new Account(0,1000,100,"","");
        accountOne.setName();
        accountOne.setAddress();
        //sets account base values
        Account accountTwo = new Account(0,1000,100,"","");
        accountTwo.setName();
        accountTwo.setAddress();
        //sets account base values and address
        Account accountThree = new Account(0,1000,100,"","");
        accountThree.setName();
        accountThree.setAddress();
        //sets account base values and address
        accountOne.showData();
        accountTwo.showData();
        accountThree.showData();
        
        
        
        
       
    }

}