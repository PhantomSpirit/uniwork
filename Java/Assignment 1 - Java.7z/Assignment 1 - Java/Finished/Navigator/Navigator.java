package Navigator;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.*;
import java.lang.*;
//imported packages

public class Navigator extends JFrame {
    
    //JPanel navigatorPane;
    JTextField navigatorText;
    JLabel Left1;
    JLabel Right1;
    JLabel Up1;
    JLabel Down1;
    

    public  Navigator() {
        super("BorderLayout Demo");
        // calling upon the super class for its inheritance usefulness
        //Button and panel creation
        JButton myLeft = new JButton("Left");
        JButton myRight = new JButton("Right");
        JButton myUp = new JButton("Up");
        JButton myDown = new JButton("Down");
        final JLabel Left1 = new JLabel("Left");
        final JLabel Right1 = new JLabel("Right");
        final JLabel Up1 = new JLabel("Up");
        final JLabel Down1 = new JLabel("Down");
        //navigatorPane = new JPanel();
        navigatorText = new JTextField(10);
        
        Container con = getContentPane();

        con.setLayout(new BorderLayout());

        // now add the buttons
        con.add(myLeft, BorderLayout.WEST);
        con.add(myUp, BorderLayout.NORTH);
        con.add(myDown, BorderLayout.SOUTH);
        con.add(myRight, BorderLayout.EAST);
        con.add(navigatorText, BorderLayout.CENTER);
        // action listeners which execute the action uppon button use and print the given text
        myLeft.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent L)
            {
                navigatorText.setText("Going Left");
            }
        });
        myRight.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent R)
            {
               navigatorText.setText("Going Right");
            }
        });
        myUp.addActionListener(new ActionListener()
         {
            public void actionPerformed(ActionEvent U)
            {
               navigatorText.setText("Going Up");
            }
        });
        myDown.addActionListener(new ActionListener()
         {
            public void actionPerformed(ActionEvent D)
            {
                navigatorText.setText("Going Down");
            }
        });
        //default close operation for "X"
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     
        pack();
        //sets the default size of the window upon launch
        setSize(400, 400);
        //sets visibility
        setVisible(true);
    }
    public static void main(String args[]){
        Navigator navDemo = new Navigator();
    }
}