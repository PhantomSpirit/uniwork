public class Premier extends Holiday
{
    private String hotelGrade;
    private String hotelName;
    private String resortName;
    
    public Premier(String start, String end, String place, String cost, String grade, String hotel, String resort)
    {
        // the super class is used here so we can take advantage of its inheritance structure
        super (start, end, place, cost);
        hotelGrade = grade;
        hotelName = hotel;
        resortName = resort;
    }
    
     public void setHotelGrade(String pumpkin)
    {
        hotelGrade = pumpkin;
    }
    
    public String getHotelGrade()
    {
        return hotelGrade;
    }
    
     public void setHotelName(String pumpkin)
    {
        hotelName = pumpkin;
    }
    
    public String getHotelName()
    {
        return hotelName;
    }
    
    public void setResortName(String pumpkin)
    {
        resortName = pumpkin;
    }
    
    public String getResortName()
    {
        return resortName;
    }
}