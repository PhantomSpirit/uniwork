
public class Holiday
{
    public String startDate;
    public String endDate;
    public String location;
    public String price;
    public static int holidayTotal = 0;
    
    public Holiday(String start, String end, String place, String cost)
    {
        // defines values in the constructor
        startDate = start;
        endDate = end;
        location = place;
        price = cost;
        holidayTotal++;
    }
    
    public void setStartDate(String pumpkin)
    {
        startDate = pumpkin;
    }
    
    public String getStartDate()
    {
        return startDate;
    }
    
    public void setEndDate(String pumpkin)
    {
        endDate = pumpkin;
    }
    
    public String getEndDate()
    {
        return endDate;
    }
    
    public void setLocation(String pumpkin)
    {
        location = pumpkin;
    }
    
    public String getLocation()
    {
        return location;
    }
    
    public void setPrice(String pumpkin)
    {
        price = pumpkin;
    }
    
    public String getPrice()
    {
        return price;
    }
}
        