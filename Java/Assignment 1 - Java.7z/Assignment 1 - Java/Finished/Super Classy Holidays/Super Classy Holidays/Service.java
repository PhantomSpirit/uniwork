public class Service
{
    public static void main(String [] args)
    {
        Holiday holidayOne = new Holiday("17/7/2016","24/7/2016", "Netherlands","£40");
        //calls upon the starting date, ending date, location and cost
        System.out.println("Holiday one start date is " + holidayOne.getStartDate());
        System.out.println("Holiday one end date is " + holidayOne.getEndDate());
        System.out.println("Holiday one location is " + holidayOne.getLocation());
        System.out.println("Holiday one price is " + holidayOne.getPrice());
        
        Holiday holidayTwo = new Holiday("25/12/2015","3/1/2016", "Florida","£2500");
        //calls upon the starting date, ending date, location and cost
        System.out.println("Holiday two start date is " + holidayTwo.getStartDate());
        System.out.println("Holiday two end date is " + holidayTwo.getEndDate());
        System.out.println("Holiday two location is " + holidayTwo.getLocation());
        System.out.println("Holiday two price is " + holidayTwo.getPrice());
    }
}
        