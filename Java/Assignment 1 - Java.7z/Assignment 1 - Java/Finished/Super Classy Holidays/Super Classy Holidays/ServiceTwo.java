public class ServiceTwo
{
    public static void main(String [] args)
    {
        Holiday holidayOne = new Holiday("19/4/2015","27/4/2015", "Netherlands","£30");
        //calls upon the starting date, ending date, location and cost
        System.out.println("Holiday one start date is " + holidayOne.getStartDate());
        System.out.println("Holiday one end date is " + holidayOne.getEndDate());
        System.out.println("Holiday one location is " + holidayOne.getLocation());
        System.out.println("Holiday one price is " + holidayOne.getPrice());
        
        Premier holidayTwo = new Premier("27/5/2015","7/6/2015", "Miami","£2000","Five Star", "Emirates", "Las Vegas");
        //calls upon the starting date, ending date, location and cost
        System.out.println("Holiday two start date is " + holidayTwo.getStartDate());
        System.out.println("Holiday two end date is " + holidayTwo.getEndDate());
        System.out.println("Holiday two location is " + holidayTwo.getLocation());
        System.out.println("Holiday two price is " + holidayTwo.getPrice());
        System.out.println("Holiday two hotel is a " + holidayTwo.getHotelGrade() + " hotel is called " +
                holidayTwo.getHotelName() + " located in the " + holidayTwo.getResortName() + " resort.");
    }
}