package GreenBottles1;


import java.util.Scanner;
public class xyGreenBottles{
    public static void main(String[] args)
    {
        System.out.println("Time to sing green bottles, How many shall we start with? ");
        int x;
        Scanner Userinput = new Scanner(System.in);
        x = Userinput.nextInt();
        
        
                
        System.out.println("How Many will fall off? ");
        int y;
        Scanner Userinput1 = new Scanner(System.in);
        y = Userinput1.nextInt();
        
     
        
        while (x <= 0)
        {
            System.out.println ("How can you start this song with negative or zero bottles? Please try again");
            x = Userinput.nextInt();
        }
        
        while (y <= 0)
        {
            System.out.println ("How can you start this song with a negative number or zero bottles to take away");
            y = Userinput1.nextInt();
            break;
        }
  
        for (x = x; x >=y;) 
               
        {
            System.out.println (x  +  " Green bottles standing on the wall");
            System.out.println (x  +  " Green bottles standing on the wall");
            System.out.println("And if " + y + " green bottles should accidently fall");
            
           
            x = x - y;
           
        // Now for the if, else stаtement for all the vаlues before x reaches 0 becuаse the final line of the song is differen
            if (x == 1)
            {
                System.out.println ("There will be " + x + " Green bottle standing on the wall");
            }
            else
            {
                System.out.println("There will be " + x + " Green bottles standing on the wall");
            }
            // Y is decremented after the line is run to make sure it stays one less than x so therefore its done at the end
            
        }

       
      
    }
}
                