package GreenBottles1;


/** 
 * Q) Make a programme that prints the 10 green bottles song with the final line being different
 * First idea would be to decrement (using --) untill X=0 in which case the loop will cancell and the final line will be printed
 *
 */

public class Greenbottles{
    /** The main method is the starting point of any program, all commands which will follow are nested under it.
     */
    public static void main(String[] args)
    {
        int x;
        // Y is defined here to be one less than x is 
        int y = 9;
       // This is executed while x is greater than 2 then once x reaches the value of 2 the if statement is executed
        for (x = 10; x >=2;) 
               
        {
            System.out.println (x  +  " Green bottles standing on the wall");
            System.out.println (x  +  " Green bottles standing on the wall");
            System.out.println("And if 1 green bottle should accidently fall");
            
           
            x--;
           
        // Now for the if, else statement for all the values before x reaches 0
            if (x == 1)
            {
                System.out.println ("There will be " + x + " Green bottle standing on the wall");
            }
            else
            {
                System.out.println("There will be " + y + " Green bottles standing on the wall");
            }
            // Y is decremented after the line is run to make sure it stays one less than x so therefore its done at the end
            y--;
        }
        // Since the final line of the song is different the final print stament is put at the end to be executed after the if/else statement
        // and when the value of x reaches 1
        System.out.println (x + " Green bottle standing on the wall");
        System.out.println (x  +  " Green bottles standing on the wall");
        System.out.println ("And if one green bottle were to accidently fall");
        System.out.println ("There will be no green bottles standing on the wall");
       
      
    }
}
                