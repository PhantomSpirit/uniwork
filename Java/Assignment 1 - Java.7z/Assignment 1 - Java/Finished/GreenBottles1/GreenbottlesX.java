package GreenBottles1;


/** 
 * Q) Make a programme that prints the 10 green bottles song with the final line being different
 * First idea would be to decrement (using --) untill X=0 in which case the loop will cancell and the final line will be printed
 *
 */
import java.util.Scanner;
public class GreenbottlesX{
    /** The main method is the starting point of any program, all commands which will follow are nested under it.
     */
    public static void main(String[] args)
    {
        System.out.println("Time to sing green bottles, How many shall we start with?");
        int x;
        // initializing X for further use in the code, and stating that it is an integer(whole number)
        Scanner Userinput = new Scanner(System.in);
        // adding a scanner input which will allow us to manually input the value of X
        x=Userinput.nextInt();
        int y = x-1;
        // initializing Y to execute a given function each time it is called upon and defining it as an integer
        
        while (x<=0)
        {
            System.out.println ("How can you start this song with negative or zero bottles? Try again");
            x=Userinput.nextInt();
        }
  
        for (x = x; x >=2;) 
        // for loop used to execute an action while x is equal to a given value       
        {
            System.out.println (x  +  " Green bottles standing on the wall");
            System.out.println("And if 1 green bottle should accidently fall");
            
           
            x--;
           
        // Now for the if else statement for all the values before x reaches 0
            if (x == 1)
            {
                System.out.println ("There will be " + x + " Green bottle standing on the wall");
            }
            else
            {
                System.out.println("There will be " + y + " Green bottles standing on the wall");
            }
            // Y is decremented after the line is run to make sure it stays one less than x so therefore its done at the end
            y--;
        }
        // Since the final line of the song is different the final print stament is put at the end to be executed after the if/else statement
        // and when the value of x reaches 1
        System.out.println (x + " Green bottle standing on the wall");
        System.out.println ("And if one green bottle were to accidently fall");
        System.out.println ("There will be no green bottles standing on the wall");
       
      
    }
}
                