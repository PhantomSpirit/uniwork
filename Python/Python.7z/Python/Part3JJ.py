import webbrowser

age = input ('Enter your age ')
answer = int(age)*365.25*24*60*60
print ('This is how many seconds',answer,'you have been alive for.')
if int(age)>=65:
    print ('You can now get a bus pass.')
    url0 = 'https://www.gov.uk/apply-for-elderly-person-bus-pass'
    webbrowser.open_new(url0)
else:
    print ('Keep working the mines.')
    url1 = 'http://i.imgur.com/Y8EHi.jpg'
    webbrowser.open_new(url1)

input("Press Enter to close")
