num1 = input("Please enter the first number: ")
num2 = input("Please enter the second number: ")


num1 = float(num1)
num2 = float(num2)


numA = num1 + num2
numB = num1 - num2
numC = num1 * num2
numD = num1 / num2


print (num1,"+",num2,"=",numA)
print (num1,"-",num2,"=",numB)
print (num1,"*",num2,"=",numC)
print (num1,"/",num2,"=",numD)


input("Please press Enter to exit")
